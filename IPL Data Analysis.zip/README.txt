# Data Mining project by Group 16

- code for the project is in python jupyter notebook iplAnalysis.ipynb
  - simply execute all cells of the jupyter notebook to run the code
- dataset `all_matches.csv` is also attached in the zip
